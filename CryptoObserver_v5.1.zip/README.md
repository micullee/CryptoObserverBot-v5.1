# CryptoObserverBot v5.1

AI-driven crypto assistant for alerts, patterns, macro analysis.