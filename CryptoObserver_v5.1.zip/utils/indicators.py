# RSI, MACD, Fibonacci
