# Handles alerts
